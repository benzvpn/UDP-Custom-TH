#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

clear
#banner
echo -e "          ░█▀▀▄ ░█▀▀▀ ░█──░█ ▀▀▀░█ " | lolcat
echo -e "          ░█▄▄▀ ░█▀▀▀ ░█▄─░█ ─▄▀── " | lolcat
echo -e "          ░█─░█ ░█▄▄▄ ░█─▄▀█ ░█▄▄▄ " | lolcat

echo ""
echo ""
echo ""
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}$allusers${ENDCOLOR}"
echo""
echo""

#deluser
echo -ne "${YELLOW}กรุณากรอกชื่อผู้ใช้ที่ต้องการลบ : "; read username
while true; do
    read -p "ต้องการลบผู้ใช้ $username หรือไม่? (Y/N) " yn
    case $yn in
        [Yy]* ) userdel $username && echo "" && echo -e "${RED}ลบผู้ใช้ $username เรียบร้อยแล้ว ${ENDCOLOR}" || echo -e "${RED}ไม่สามารถลบผู้ใช้ $username ได้ ${ENDCOLOR}"; break;;
        [Nn]* ) echo -e "${RED}\nยกเลิกการลบแล้ว${ENDCOLOR}"&&break;;
        * ) echo "กรุณาตอบว่า ใช่ หรือ ไม่";;
    esac
done

echo -e "\nกด Enter เพื่อกลับไปที่เมนูหลัก"; read
menu
