#!/bin/bash

GREEN="\e[32m"
ENDCOLOR="\e[0m"

clear
echo -e "          ░█▀▀▄ ░█▀▀▀ ░█──░█ ▀▀▀░█ " | lolcat
echo -e "          ░█▄▄▀ ░█▀▀▀ ░█▄─░█ ─▄▀── " | lolcat
echo -e "          ░█─░█ ░█▄▄▄ ░█─▄▀█ ░█▄▄▄ " | lolcat
echo ""
echo ""
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}$allusers${ENDCOLOR}"

echo -e "\nกด Enter เพื่อกลับไปที่เมนูหลัก"; read
menu
