#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
ENDCOLOR="\e[0m"

spinner()
{
    #Loading spinner
    local pid=$!
    local delay=0.75
    local spinstr='|/-\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

remove_script()
{
    systemctl stop udp-custom
    rm -rf /root/udp
    rm -rf /etc/Sslablk1
    systemctl daemon-reload
    rm -f /usr/local/bin/menu
    sed -i ':a;N;$!ba;s/\n\/bin\/false//g' /etc/shells
}

remove_confirm()
{
echo -ne "${RED}● กำลังลบสคริปต์       ..."
remove_script >/dev/null 2>&1 &
spinner
echo -ne "\tเสร็จสิ้น"
echo -e "${ENDCOLOR}"
}
echo " ขอบคุณที่ใช้สคริปต์นี้"
echo ""
echo "โดย Project SSLaB LK"
clear
while true; do
    read -p "ต้องการลบสคริปต์ออกหรือไม่? (Y/N) " yn
    case $yn in
        [Yy]* ) remove_confirm;echo -e "ลบเสร็จสิ้น กด Enter เพื่อออกจากโปรแกรม";read;break;;
        [Nn]* ) echo -e "${RED}ยกเลิกการลบ !! กด Enter เพื่อกลับไปที่เมนูหลัก${ENDCOLOR}";read;menu;break;;
        * ) echo "กรุณาตอบว่า ใช่ หรือ ไม่";;
    esac
done
