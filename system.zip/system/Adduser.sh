#!/bin/bash

#font colors
IP=$(cat /etc/IP)
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

s_ip=$(wget -qO- https://ipecho.net/plain ; echo)

clear

#add users

echo -e "          ░█▀▀▄ ░█▀▀▀ ░█──░█ ▀▀▀░█ " | lolcat
echo -e "          ░█▄▄▀ ░█▀▀▀ ░█▄─░█ ─▄▀── " | lolcat
echo -e "          ░█─░█ ░█▄▄▄ ░█─▄▀█ ░█▄▄▄ " | lolcat
echo ""
echo ""
echo ""

echo -ne "${YELLOW}กรุณากรอกชื่อผู้ใช้ : "; read username
while true; do
    read -p "ต้องการสร้างรหัสผ่านแบบสุ่มหรือไม่? (Y/N) " yn
    case $yn in
        [Yy]* ) password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c${1:-9};echo;); break;;
        [Nn]* ) echo -ne "กรุณากรอกรหัสผ่าน (แนะนำให้ใช้รหัสผ่านที่ซับซ้อน) : "; read password; break;;
        * ) echo "กรุณาตอบว่า ใช่ หรือ ไม่";;
    esac
done
echo -ne "กรุณากรอกจำนวนวันก่อนหมดอายุ : ";read nod
exd=$(date +%F  -d "$nod days")

read -p "จำนวนล็อกอินสูงสุด: " maxlogins
echo "$username  hard  maxlogins ${maxlogins}" >/etc/security/limits.d/"$username"

useradd -e $exd -M -N -s /bin/false $username && echo "$username:$password" | chpasswd &&
clear &&
echo -e  "${YELLOW} กำลังสร้างผู้ใช้ กรุณารอสักครู่.."
sleep 3
clear
echo -e "          ░█▀▀▄ ░█▀▀▀ ░█──░█ ▀▀▀░█ " | lolcat
echo -e "          ░█▄▄▀ ░█▀▀▀ ░█▄─░█ ─▄▀── " | lolcat
echo -e "          ░█─░█ ░█▄▄▄ ░█─▄▀█ ░█▄▄▄ " | lolcat

echo ""
echo ""
echo -e "========== บัญชี SSH & OVPN =========="
echo -e ""
echo -e ""
echo -e "${GREEN}\n• ที่อยู่ IP : ${YELLOW}$s_ip"
echo -e "${GREEN}\n• ชื่อผู้ใช้ :${YELLOW} $username"
echo -e "${GREEN}\n• รหัสผ่าน :${YELLOW} $password"
echo -e "${GREEN}\n• วันหมดอายุ :${YELLOW} $exd"
echo -e "${GREEN}\n• ล็อกอินสูงสุด :${YELLOW} $maxlogins${ENDCOLOR}"
#echo -e "======================================="
echo -e ""
#echo -e ""
echo -e "================= พอร์ต ================="
echo -e ""
echo -e "${GREEN}\n• Badvpn    : ${YELLOW}1-65535${ENDCOLOR}"
echo -e ""
echo -e "========== Http Custom UDP ==========="
echo -e " "
echo -e "$s_ip:1-65535@$username:$password"
echo -e ""
echo -e "======================================="
echo""
echo -e " >> ติดต่อทาง Telegram : @shaystudiolab"
echo -e " >> ติดต่อทาง Github : @noobconner21"
echo""
echo -e "======================================="
#echo -e "${RED}\nไม่สามารถเพิ่มผู้ใช้ $username ได้ กรุณาลองใหม่อีกครั้ง"
echo ""
echo ""

#return to panel

echo -e "\nกด Enter เพื่อกลับไปที่เมนูหลัก"; read
menu
